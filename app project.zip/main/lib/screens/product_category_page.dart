import 'package:flutter/material.dart';

class ProductCategoryPage extends StatelessWidget {
  final Map<String, List<Map<String, dynamic>>> products = {
    'Phone': [
      {
        'name': 'iPhone 15',
        'image': 'https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1708678829/Croma%20Assets/Communication/Mobiles/Images/300822_0_vy3iid.png',
        'price': '\$1199.9',
        'specs': {
          'RAM': '6 GB',
          'Storage': '128 GB',
          'Camera': '48 MP',
          'Battery': '3300 mAh'
        }
      },
      {
        'name': 'Samsung S23',
        'image': 'https://www.pngall.com/wp-content/uploads/13/Galaxy-S23-Ultra-PNG-Free-Image.png',
        'price': '\$999.9',
        'specs': {
          'RAM': '8 GB',
          'Storage': '256 GB',
          'Camera': '50 MP',
          'Battery': '3900 mAh'
        }
      },
      {
        'name': 'Infinix Hot 50',
        'image': 'https://www.pakmobizone.pk/wp-content/uploads/2024/10/Infinix-Hot-50-4G-Sleek-Black-1.png',
        'price': '\$299.99',
        'specs': {
          'RAM': '4 GB',
          'Storage': '64 GB',
          'Camera': '16 MP',
          'Battery': '5000 mAh'
        }
      },
      {
        'name': 'Asus ROG',
        'image': 'https://dlcdnwebimgs.asus.com/gain/79867C9B-8893-45F3-89E2-C3DD17E970EC',
        'price': '\$999.99',
        'specs': {
          'RAM': '16 GB',
          'Storage': '512 GB',
          'Camera': '48 MP',
          'Battery': '6000 mAh'
        }
      },
    ],
    'Laptop': [
      {
        'name': 'MacBook Pro',
        'image': 'https://www.freepnglogos.com/uploads/macbook-png/apple-macbook-pro-with-retina-display-hands-preview-4.png',
        'price': '\$1999.9',
        'specs': {
          'RAM': '16 GB',
          'Storage': '512 GB SSD',
          'Processor': 'Apple M3',
          'Battery': '11 hours'
        }
      },
      {
        'name': 'Dell XPS',
        'image': 'https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/xps-notebooks/xps-15-9520/media-gallery/black/laptop-xps-9520-t-black-gallery-3.psd?fmt=png-alpha&pscan=auto&scl=1&hei=402&wid=653&qlt=100,1&resMode=sharp2&size=653,402&chrss=full',
        'price': '\$1299.9',
        'specs': {
          'RAM': '16 GB',
          'Storage': '1 TB SSD',
          'Processor': 'Intel i7',
          'Battery': '5 hours'
        }

      },
      {
        'name': 'HP Victus 7Z586 EA',
        'image': 'https://www.hp.com/wcsstore/hpusstore/Treatment/mdps/Q3FY21_omen_victus16/omen_victus_heroImage1.png',
        'price': '\$1499.99',
        'specs': {
          'RAM': '32 GB',
          'Storage': '2 TB SSD',
          'Processor': 'AMD Ryzen 7',
          'Battery': '6 hours'
        }

      },
      {
        'name': 'HP Omen',
        'image': 'https://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c05578812.png',
        'price': '\$1599.99',
        'specs': {
          'RAM': '32 GB',
          'Storage': '1 TB SSD',
          'Processor': 'core i7',
          'Battery': '6 hours'
        }

      },
    ],
  };

  @override
  Widget build(BuildContext context) {
    final String category = ModalRoute.of(context)?.settings.arguments as String;
    final items = products[category] ?? [];

    return Scaffold(
      appBar: AppBar(title: Text('$category Products')),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          final product = items[index];
          return ListTile(
            title: Text(product['name']),
            subtitle: Text(product['price']),
            leading: Image.network(product['image'], width: 50),
            onTap: () {
              Navigator.pushNamed(context, '/product-detail', arguments: product);
            },
          );
        },
      ),
    );
  }
}
