import 'package:flutter/material.dart';

class ProductSelectionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Select Category')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/product-category', arguments: 'Phone');
              },
              child: Text('Phones'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/product-category', arguments: 'Laptop');
              },
              child: Text('Laptops'),
            ),
          ],
        ),
      ),
    );
  }
}
