import 'package:flutter/material.dart';

class ProductDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> product = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final Map<String, dynamic> specs = Map<String, dynamic>.from(product['specs']);

    return Scaffold(
      appBar: AppBar(title: Text(product['name'])),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Image.network(product['image'], height: 200)),
            SizedBox(height: 20),
            Text('Product: ${product['name']}', style: TextStyle(fontSize: 22)),
            Text('Price: ${product['price']}', style: TextStyle(fontSize: 20, color: Colors.lightGreen[700])),
            SizedBox(height: 20),
            Text('Specifications:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            ...specs.entries.map((entry) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 2.0),
              child: Text('${entry.key}: ${entry.value}', style: TextStyle(fontSize: 16)),
            )),
          ],
        ),
      ),
    );
  }
}
