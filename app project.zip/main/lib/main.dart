import 'package:flutter/material.dart';
import 'screens/home_page.dart';
import 'screens/product_selection_page.dart';
import 'screens/product_category_page.dart';
import 'screens/product_detail_page.dart';
import 'screens/about_us_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isDarkTheme = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product App',
      theme: isDarkTheme ? ThemeData.dark() : ThemeData.light(),
      debugShowCheckedModeBanner: false,
      routes: {
        '/': (context) => HomePage(toggleTheme: toggleTheme),
        '/product-selection': (context) => ProductSelectionPage(),
        '/product-category': (context) => ProductCategoryPage(),
        '/product-detail': (context) => ProductDetailPage(),
        '/about-us': (context) => AboutUsPage(),
      },
    );
  }

  void toggleTheme() {
    setState(() {
      isDarkTheme = !isDarkTheme;
    });
  }
}
